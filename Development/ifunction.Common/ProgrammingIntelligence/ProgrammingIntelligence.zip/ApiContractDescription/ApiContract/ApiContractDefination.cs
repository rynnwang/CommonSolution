﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Beyova.ProgrammingIntelligence
{
    /// <summary>
    /// Class ApiContractDefinition.
    /// </summary>
    public class ApiContractDefinition : AbstractApiContractDescription
    {
        /// <summary>
        /// Gets or sets a value indicating whether [token required].
        /// </summary>
        /// <value><c>null</c> if [token required] contains no value, <c>true</c> if [token required]; otherwise, <c>false</c>.</value>
        public bool? TokenRequired { get; set; }

        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>The version.</value>
        public string Version { get; set; }

        /// <summary>
        /// Gets or sets the API data contracts.
        /// </summary>
        /// <value>The API data contracts.</value>
        public List<ApiDataContractDefinition> ApiDataContracts { get; set; }

        /// <summary>
        /// Gets or sets the API operations.
        /// </summary>
        /// <value>The API operations.</value>
        public List<ApiOperationDefinition> ApiOperations { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiContractDefinition"/> class.
        /// </summary>
        public ApiContractDefinition()
            : base()
        {
            this.ApiOperations = new List<ApiOperationDefinition>();
            this.ApiDataContracts = new List<ApiDataContractDefinition>();
        }

        /// <summary>
        /// Fills the property values by JToken.
        /// </summary>
        /// <param name="jToken">The j token.</param>
        public override void FillPropertyValuesByJToken(JToken jToken)
        {
            base.FillPropertyValuesByJToken(jToken);
            this.Version = jToken.Value<string>("Version");
            this.TokenRequired = jToken.Value<bool?>("TokenRequired");

            this.ApiDataContracts = jToken.Value<List<ApiDataContractDefinition>>("ApiDataContracts");
            this.ApiOperations = jToken.Value<List<ApiOperationDefinition>>("ApiOperations");
        }

        /// <summary>
        /// Writes the customized json.
        /// </summary>
        /// <param name="writer">The writer.</param>
        /// <param name="value">The value.</param>
        /// <param name="serializer">The serializer.</param>
        protected override void WriteCustomizedJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            ApiContractDefinition definition = value as ApiContractDefinition;

            if (definition != null)
            {
                writer.WritePropertyName("TokenRequired");
                serializer.Serialize(writer, definition.TokenRequired);

                writer.WritePropertyName("Version");
                serializer.Serialize(writer, definition.Version);

                writer.WritePropertyName("ApiDataContracts");
                serializer.Serialize(writer, definition.ApiDataContracts);

                writer.WritePropertyName("ApiOperations");
                serializer.Serialize(writer, definition.ApiOperations);
            }
        }
    }
}
