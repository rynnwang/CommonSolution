﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using ifunction;
using ifunction.RestApi;
using Newtonsoft.Json;

namespace Beyova.ProgrammingIntelligence
{
    /// <summary>
    /// Class AbstractApiContractReference.
    /// </summary>
    [JsonConverter(typeof(ApiContractReferenceJsonConverter))]
    public abstract class AbstractApiContractReference
    {
        /// <summary>
        /// Gets or sets the type of the special reference.
        /// </summary>
        /// <value>The type of the special reference.</value>
        public ApiContractDataType SpecialReferenceType { get; protected set; }

        /// <summary>
        /// Gets the reference instance.
        /// </summary>
        /// <value>The reference instance.</value>
        public abstract ApiDataContractDefinition ReferenceInstance
        {
            get;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AbstractApiContractReference" /> class.
        /// </summary>
        /// <param name="specialReferenceType">Type of the special reference.</param>
        public AbstractApiContractReference(ApiContractDataType specialReferenceType)
        {
            this.SpecialReferenceType = specialReferenceType;
        }
    }
}
