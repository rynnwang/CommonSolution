﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using ifunction;
using ifunction.RestApi;
using Newtonsoft.Json;

namespace Beyova.ProgrammingIntelligence
{
    /// <summary>
    /// Class ApiDictionaryContractReference.
    /// </summary>
    public class ApiDictionaryContractReference : AbstractApiContractReference
    {
        /// <summary>
        /// Gets or sets the type of the key.
        /// </summary>
        /// <value>The type of the key.</value>
        public AbstractApiContractReference KeyType { get; set; }

        /// <summary>
        /// Gets or sets the type of the value.
        /// </summary>
        /// <value>The type of the value.</value>
        public AbstractApiContractReference ValueType { get; set; }

        /// <summary>
        /// Gets the reference instance.
        /// </summary>
        /// <value>The reference instance.</value>
        public override ApiDataContractDefinition ReferenceInstance
        {
            get
            {
                var dictionaryContract = ApiContract.CreateApiDataContractDefinitionInstance(ApiContractDataType.Dictionary) as DictionaryDataContractDefinition;

                dictionaryContract.KeyType = KeyType;
                dictionaryContract.ValueType = ValueType;

                return dictionaryContract;
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiDictionaryContractReference" /> class.
        /// </summary>
        public ApiDictionaryContractReference() : base(ApiContractDataType.Dictionary)
        {
        }
    }
}
