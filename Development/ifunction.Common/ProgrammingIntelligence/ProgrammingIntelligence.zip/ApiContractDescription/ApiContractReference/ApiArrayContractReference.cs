﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using ifunction;
using ifunction.RestApi;
using Newtonsoft.Json;

namespace Beyova.ProgrammingIntelligence
{
    /// <summary>
    /// Class ApiArrayContractReference.
    /// </summary>
    public class ApiArrayContractReference : AbstractApiContractReference
    {
        /// <summary>
        /// Gets or sets the type of the value.
        /// </summary>
        /// <value>The type of the value.</value>
        public AbstractApiContractReference ValueType { get; set; }

        /// <summary>
        /// Gets the reference instance.
        /// </summary>
        /// <value>The reference instance.</value>
        public override ApiDataContractDefinition ReferenceInstance
        {
            get
            {
                var arrayDefinition = ApiContract.CreateApiDataContractDefinitionInstance(ApiContractDataType.Array) as ArrayListDataContractDefinition;
                arrayDefinition.ValueType = ValueType;
                return arrayDefinition;
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiArrayContractReference" /> class.
        /// </summary>
        public ApiArrayContractReference() : base(ApiContractDataType.Array)
        {
        }
    }
}
